# Favour Lung'anyí - Personal Website

This is a personal portfolio website hosted on GitHub Pages. It displays:

- Personal details (Name, National ID, Date of Birth)
- Embedded certificates viewable in-browser
- A placeholder for CV
- Dark-themed responsive design

## 🧾 Features

- HTML/CSS only (static site)
- No frameworks required
- Easy to update via GitHub

## 📁 Structure

```
/
├── index.html
└── certs/
    ├── Business-Proficient English Certificate.pdf
    ├── CERTIFICATE_OF_ACHIEVEMENT ICT AUTHORITY.pdf
    └── Intermediate Python certificate.pdf
```

## 🌐 How to Deploy on GitHub Pages

1. Upload all files to a public GitHub repository
2. Go to **Settings > Pages**
3. Select `main` branch, root (`/`)
4. GitHub will give you a public link to access your site

